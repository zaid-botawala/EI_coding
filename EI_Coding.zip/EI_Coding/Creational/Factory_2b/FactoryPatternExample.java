// Factory pattern

// Product Interface
interface Notification {
    void notifyUser();
}

// Concrete Product 1
class SMSNotification implements Notification {
    @Override
    public void notifyUser() {
        System.out.println("Sending SMS notification.");
    }
}

// Concrete Product 2
class EmailNotification implements Notification {
    @Override
    public void notifyUser() {
        System.out.println("Sending Email notification.");
    }
}

// Factory class
class NotificationFactory {
    public Notification createNotification(String channel) {
        if (channel.equalsIgnoreCase("SMS")) {
            return new SMSNotification();
        } else if (channel.equalsIgnoreCase("Email")) {
            return new EmailNotification();
        }
        return null;
    }
}

// Main class
public class FactoryPatternExample {
    public static void main(String[] args) {
        NotificationFactory factory = new NotificationFactory();
        
        Notification notification = factory.createNotification("SMS");
        notification.notifyUser();

        notification = factory.createNotification("Email");
        notification.notifyUser();
    }
}

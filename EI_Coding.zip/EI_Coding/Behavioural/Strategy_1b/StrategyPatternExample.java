// Strategy pattern

// Strategy interface
interface PaymentStrategy {
    void pay(int amount);
}

// Concrete Strategy A
class CreditCardPayment implements PaymentStrategy {
    @Override
    public void pay(int amount) {
        System.out.println("Paid " + amount + " using Credit Card.");
    }
}

// Concrete Strategy B
class PayPalPayment implements PaymentStrategy {
    @Override
    public void pay(int amount) {
        System.out.println("Paid " + amount + " using PayPal.");
    }
}

// Context
class ShoppingCart {
    private PaymentStrategy paymentStrategy;

    public void setPaymentStrategy(PaymentStrategy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
    }

    public void checkout(int amount) {
        paymentStrategy.pay(amount);
    }
}

// Main class
public class StrategyPatternExample {
    public static void main(String[] args) {
        ShoppingCart cart = new ShoppingCart();
        
        // Using Credit Card payment
        cart.setPaymentStrategy(new CreditCardPayment());
        cart.checkout(100);

        // Using PayPal payment
        cart.setPaymentStrategy(new PayPalPayment());
        cart.checkout(200);
    }
}

import java.util.List;
import java.util.ArrayList;

// Command interface representing any rover command
interface Command {
    void execute();
}

// Rover class
class Rover {
    private Position position;
    private Grid grid;

    public Rover(Position position, Grid grid) {
        this.position = position;
        this.grid = grid;
    }

    public void moveForward() {
        position.moveForward(grid);
    }

    public void turnLeft() {
        position.turnLeft();
    }

    public void turnRight() {
        position.turnRight();
    }

    public String reportStatus() {
        return "Rover is at (" + position.getX() + ", " + position.getY() + ") facing " + position.getDirection().toString();
    }
}

// Command for moving the rover forward
class MoveCommand implements Command {
    private Rover rover;

    public MoveCommand(Rover rover) {
        this.rover = rover;
    }

    @Override
    public void execute() {
        rover.moveForward();
    }
}

// Command for turning the rover left
class TurnLeftCommand implements Command {
    private Rover rover;

    public TurnLeftCommand(Rover rover) {
        this.rover = rover;
    }

    @Override
    public void execute() {
        rover.turnLeft();
    }
}

// Command for turning the rover right
class TurnRightCommand implements Command {
    private Rover rover;

    public TurnRightCommand(Rover rover) {
        this.rover = rover;
    }

    @Override
    public void execute() {
        rover.turnRight();
    }
}

// Direction enumeration
enum Direction {
    N, E, S, W;

    public Direction turnLeft() {
        switch (this) {
            case N: return W;
            case W: return S;
            case S: return E;
            case E: return N;
            default: throw new IllegalStateException("Invalid Direction");
        }
    }

    public Direction turnRight() {
        switch (this) {
            case N: return E;
            case E: return S;
            case S: return W;
            case W: return N;
            default: throw new IllegalStateException("Invalid Direction");
        }
    }
}

// Position class encapsulates the rover's current coordinates and direction
class Position {
    private int x, y;
    private Direction direction;

    public Position(int x, int y, Direction direction) {
        this.x = x;
        this.y = y;
        this.direction = direction;
    }

    public void moveForward(Grid grid) {
        int newX = x, newY = y;
        switch (direction) {
            case N: newY++; break;
            case E: newX++; break;
            case S: newY--; break;
            case W: newX--; break;
        }
        if (grid.isPositionValid(newX, newY)) {
            x = newX;
            y = newY;
        } else {
            System.out.println("Obstacle or boundary detected! Rover cannot move forward.");
        }
    }

    public void turnLeft() {
        direction = direction.turnLeft();
    }

    public void turnRight() {
        direction = direction.turnRight();
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public Direction getDirection() {
        return direction;
    }
}

// Grid class represents the terrain and obstacles
class Grid {
    private int width, height;
    private boolean[][] obstacles;

    public Grid(int width, int height, int[][] obstaclePositions) {
        this.width = width;
        this.height = height;
        this.obstacles = new boolean[width][height];
        for (int[] pos : obstaclePositions) {
            obstacles[pos[0]][pos[1]] = true;
        }
    }

    public boolean isPositionValid(int x, int y) {
        if (x < 0 || x >= width || y < 0 || y >= height || obstacles[x][y]) {
            return false;
        }
        return true;
    }
}

// CommandInvoker class to execute commands
class CommandInvoker {
    private List<Command> commands = new ArrayList<>();

    public void addCommand(Command command) {
        commands.add(command);
    }

    public void executeCommands() {
        for (Command command : commands) {
            command.execute();
        }
    }
}

// Main class
public class MarsRoverApp {
    public static void main(String[] args) {
        // Create grid with obstacles
        int[][] obstacles = { { 2, 2 }, { 3, 5 } };
        Grid grid = new Grid(10, 10, obstacles);

        // Initialize rover's starting positionz
        Position startPosition = new Position(0, 0, Direction.N);
        Rover rover = new Rover(startPosition, grid);

        // Create commands
        Command moveCommand = new MoveCommand(rover);
        Command turnLeftCommand = new TurnLeftCommand(rover);
        Command turnRightCommand = new TurnRightCommand(rover);

        // Add commands to invoker
        CommandInvoker invoker = new CommandInvoker();
        invoker.addCommand(moveCommand);  // Move forward
        invoker.addCommand(moveCommand);  // Move forward
        invoker.addCommand(turnRightCommand);  // Turn right
        invoker.addCommand(moveCommand);  // Move forward
        invoker.addCommand(turnLeftCommand);  // Turn left
        invoker.addCommand(moveCommand);  // Move forward

        // Execute commands
        invoker.executeCommands();

        // Print rover's final position and status
        System.out.println(rover.reportStatus());
    }
}

// Facade pattern

// Subsystem 1
class CPU {
    public void start() {
        System.out.println("CPU started.");
    }
}

// Subsystem 2
class Memory {
    public void load() {
        System.out.println("Memory loaded.");
    }
}

// Subsystem 3
class HardDrive {
    public void read() {
        System.out.println("Hard drive reading data.");
    }
}

// Facade class
class ComputerFacade {
    private CPU cpu;
    private Memory memory;
    private HardDrive hardDrive;

    public ComputerFacade() {
        cpu = new CPU();
        memory = new Memory();
        hardDrive = new HardDrive();
    }

    public void startComputer() {
        cpu.start();
        memory.load();
        hardDrive.read();
        System.out.println("Computer started.");
    }
}

// Main class
public class FacadePatternExample {
    public static void main(String[] args) {
        ComputerFacade computer = new ComputerFacade();
        computer.startComputer();
    }
}
